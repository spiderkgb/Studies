from distutils.core import setup

setup (name='test',
 version='1.0.0',
 descriptio='Python test setup',
 author='Antonio',
 author_email='tonnytg@gmail.com',
 url='http://linuxresort.blogspot.com.br',
 packages=['test'],
 ) 
